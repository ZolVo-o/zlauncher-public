package com.zlauncher.access;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class ZLauncherAccessClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.zlauncher_access";

    private static class_304 toggleModeKey;
    private static class_304 switchSideKey;
    private static class_304 sneakToggleKey;
    private static class_304 sprintToggleKey;

    private static AccessConfig config;
    private static boolean remapApplied = false;
    private static boolean sneaking = false;
    private static boolean sprinting = false;

    @Override
    public void onInitializeClient() {
        config = AccessConfig.load();

        toggleModeKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.zlauncher_access.toggle_mode",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F8,
                CATEGORY
        ));
        switchSideKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.zlauncher_access.switch_side",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F9,
                CATEGORY
        ));
        sneakToggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.zlauncher_access.sneak_toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_ALT,
                CATEGORY
        ));
        sprintToggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.zlauncher_access.sprint_toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_BACKSLASH,
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(class_310 client) {
        if (client == null || client.field_1690 == null) {
            return;
        }

        while (toggleModeKey.method_1436()) {
            config.accessibilityMode = !config.accessibilityMode;
            config.save();
            applyOrResetRemap(client);
            send(client, "Спецрежим: " + (config.accessibilityMode ? "ВКЛ" : "ВЫКЛ"));
        }

        while (switchSideKey.method_1436()) {
            config.side = "right".equalsIgnoreCase(config.side) ? "left" : "right";
            config.save();
            if (config.accessibilityMode) {
                applyRemap(client);
            }
            send(client, "Сторона управления: " + ("right".equalsIgnoreCase(config.side) ? "ПРАВАЯ" : "ЛЕВАЯ"));
        }

        if (!config.accessibilityMode) {
            if (remapApplied) {
                resetRemap(client);
            }
            return;
        }

        if (!remapApplied) {
            applyRemap(client);
        }

        while (sneakToggleKey.method_1436()) {
            sneaking = !sneaking;
            client.field_1690.field_1832.method_23481(sneaking);
            send(client, "Приседание: " + (sneaking ? "ВКЛ" : "ВЫКЛ"));
        }

        while (sprintToggleKey.method_1436()) {
            sprinting = !sprinting;
            client.field_1690.field_1867.method_23481(sprinting);
            send(client, "Спринт: " + (sprinting ? "ВКЛ" : "ВЫКЛ"));
        }
    }

    private void applyOrResetRemap(class_310 client) {
        if (config.accessibilityMode) {
            applyRemap(client);
        } else {
            resetRemap(client);
        }
    }

    private void applyRemap(class_310 client) {
        if ("right".equalsIgnoreCase(config.side)) {
            client.field_1690.field_1894.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_I, 0));
            client.field_1690.field_1881.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_K, 0));
            client.field_1690.field_1913.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_J, 0));
            client.field_1690.field_1849.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_L, 0));
            client.field_1690.field_1903.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_O, 0));
            client.field_1690.field_1832.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_U, 0));
            client.field_1690.field_1867.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_P, 0));
            client.field_1690.field_1822.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_H, 0));
            client.field_1690.field_1886.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_ENTER, 0));
            client.field_1690.field_1904.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_RIGHT_SHIFT, 0));
        } else {
            client.field_1690.field_1894.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_W, 0));
            client.field_1690.field_1881.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_S, 0));
            client.field_1690.field_1913.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_A, 0));
            client.field_1690.field_1849.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_D, 0));
            client.field_1690.field_1903.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_SPACE, 0));
            client.field_1690.field_1832.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_LEFT_SHIFT, 0));
            client.field_1690.field_1867.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_LEFT_CONTROL, 0));
            client.field_1690.field_1822.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_E, 0));
        }

        remapApplied = true;
        class_304.method_1426();
        client.field_1690.method_1640();
    }

    private void resetRemap(class_310 client) {
        client.field_1690.field_1894.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_W, 0));
        client.field_1690.field_1881.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_S, 0));
        client.field_1690.field_1913.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_A, 0));
        client.field_1690.field_1849.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_D, 0));
        client.field_1690.field_1903.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_SPACE, 0));
        client.field_1690.field_1832.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_LEFT_SHIFT, 0));
        client.field_1690.field_1867.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_LEFT_CONTROL, 0));
        client.field_1690.field_1822.method_1422(class_3675.method_15985(GLFW.GLFW_KEY_E, 0));
        client.field_1690.field_1886.method_1422(class_3675.class_307.field_1672.method_1447(GLFW.GLFW_MOUSE_BUTTON_LEFT));
        client.field_1690.field_1904.method_1422(class_3675.class_307.field_1672.method_1447(GLFW.GLFW_MOUSE_BUTTON_RIGHT));

        remapApplied = false;
        sneaking = false;
        sprinting = false;
        client.field_1690.field_1832.method_23481(false);
        client.field_1690.field_1867.method_23481(false);
        class_304.method_1426();
        client.field_1690.method_1640();
    }

    private static void send(class_310 client, String message) {
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[ZAccess] " + message), true);
        }
    }

}
